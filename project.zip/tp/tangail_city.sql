-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 26, 2018 at 02:11 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tangail_city`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `user_name`, `user_password`) VALUES
(1, 'admin', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `b_id` int(255) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `book_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `writer` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `publish_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`b_id`, `book_name`, `book_id`, `writer`, `publish_date`) VALUES
(8, 'DUET Physics', '6677', 'রাকিবুল ইসলাম', '2018-09-07'),
(10, 'DUET English', 'S-104', 'Jwel', '2018-09-16'),
(11, 'DUET Math', 'S-105', 'Sadiq', '2018-09-16'),
(12, 'CSE', 'S-106', 'রাকিবুল ইসলাম', '2018-09-16'),
(13, 'DUET Physics', 'S-107', 'Jobayer Hasan', '2018-09-17'),
(14, 'DUET Math', 'S-111', 'Atahur', '2018-10-25');

-- --------------------------------------------------------

--
-- Table structure for table `client_info`
--

CREATE TABLE IF NOT EXISTS `client_info` (
  `m_id` int(255) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(255) DEFAULT NULL,
  `dokaner_name` varchar(255) NOT NULL,
  `shop_id` int(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile` int(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `client_info`
--

INSERT INTO `client_info` (`m_id`, `c_name`, `dokaner_name`, `shop_id`, `address`, `mobile`, `email`) VALUES
(38, ' রাকিবুল ইসলাম', 'ডুয়েট বই বিতান', 105, 'Acota Super Market', 1777342572, 'rakibdeveloper@gmail.com'),
(39, ' masud', 'duet boi-Bitan', 1222, 'Acota Super Market', 1111233, 'rakibdeveloper@gmail.com'),
(40, ' Md. Helal', 'Helal Photo Copy', 100, 'DUET gate', 1777342572, 'rakibdeveloper@gmail.com'),
(41, 'রাকিবুল ইসলাম', 'duet boi-Bitan', 110, 'Acota Super Market', 1111233, 'rakibdeveloper@gmail.com'),
(42, 'রাকিবুল ইসলাম', 'duet boi-Bitan', 112, 'Acota Super Market', 0, 'rakibdeveloper@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE IF NOT EXISTS `cost` (
  `cost_id` int(255) NOT NULL AUTO_INCREMENT,
  `cost_type` int(255) NOT NULL,
  `cost_biboron` varchar(255) NOT NULL,
  `cost_taka` int(255) NOT NULL,
  `day` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `cost_date` varchar(255) NOT NULL,
  PRIMARY KEY (`cost_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`cost_id`, `cost_type`, `cost_biboron`, `cost_taka`, `day`, `month`, `year`, `cost_date`) VALUES
(2, 0, 'breakfast', 200, 26, 4, 2016, '10-05-2016'),
(4, 0, 'tyrtrty', 455, 26, 4, 2016, ''),
(5, 0, 'breakfast', 200, 1, 5, 2016, ''),
(6, 0, 'breakfast', 200, 1, 5, 2016, ''),
(7, 0, 'tyrtrty', 455, 1, 5, 2016, ''),
(8, 0, 'tyrtrty', 200, 1, 5, 2016, ''),
(9, 0, 'fjsldfjl', 200, 17, 5, 2016, '17-05-2016'),
(10, 0, 'fjsldfjl', 200, 17, 5, 2016, '17-05-2016'),
(11, 0, 'computer ', 0, 18, 5, 2016, '18-05-2016'),
(12, 0, 'computer', 200, 18, 5, 2016, '18-05-2016'),
(13, 0, 'sdfag', 566, 26, 11, 2016, '26-11-2016'),
(14, 0, 'abakldf', 566, 26, 11, 2016, '26-11-2016'),
(15, 0, 'bread', 100, 12, 10, 2017, '12-10-2017'),
(16, 0, 'cechk ', 50, 29, 8, 2018, '29-08-2018'),
(17, 0, 'cechk', 50, 12, 9, 2018, '2018-09-11'),
(18, 0, '1', 50, 14, 9, 2018, '2018-09-10'),
(20, 0, '1', 50, 0, 0, 0, '2018-09-13'),
(21, 0, '1', 50, 0, 0, 0, '2018-10-03'),
(22, 4, 'cechk', 50, 0, 0, 0, '2018-09-14'),
(23, 4, 'cechk', 50, 0, 0, 0, '2018-09-14'),
(24, 3, 'offics stap', 299999, 0, 0, 0, '2018-09-14'),
(25, 1, 'offics stap', 799, 0, 0, 0, '2018-09-14'),
(26, 4, 'offics stap', 299999, 0, 0, 0, '2018-10-03'),
(27, 4, 'offics stap', 299999, 0, 0, 0, '2018-09-02'),
(28, 1, 'fgdfg', 5000, 0, 0, 0, '2018-09-10');

-- --------------------------------------------------------

--
-- Table structure for table `dokaner_vara`
--

CREATE TABLE IF NOT EXISTS `dokaner_vara` (
  `dokan_id` int(11) NOT NULL AUTO_INCREMENT,
  `market_name` varchar(255) NOT NULL,
  `dokan_no` int(11) NOT NULL,
  `vara` int(11) NOT NULL,
  `vara_kothai` varchar(255) NOT NULL,
  `jan` varchar(2) DEFAULT NULL,
  `feb` varchar(2) DEFAULT NULL,
  `mar` varchar(2) DEFAULT NULL,
  `apr` varchar(2) DEFAULT NULL,
  `may` varchar(2) DEFAULT NULL,
  `jun` varchar(2) DEFAULT NULL,
  `jul` varchar(2) DEFAULT NULL,
  `aug` varchar(2) DEFAULT NULL,
  `sep` varchar(2) DEFAULT NULL,
  `oct` varchar(2) DEFAULT NULL,
  `nov` varchar(2) DEFAULT NULL,
  `dec` varchar(2) DEFAULT NULL,
  `year_name` varchar(255) NOT NULL,
  `joma_date` varchar(255) NOT NULL,
  `roshid_no` int(11) NOT NULL,
  PRIMARY KEY (`dokan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `dokaner_vara`
--

INSERT INTO `dokaner_vara` (`dokan_id`, `market_name`, `dokan_no`, `vara`, `vara_kothai`, `jan`, `feb`, `mar`, `apr`, `may`, `jun`, `jul`, `aug`, `sep`, `oct`, `nov`, `dec`, `year_name`, `joma_date`, `roshid_no`) VALUES
(1, 'tcl', 1, 1000, 'falkjl;ajf', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016', '30-05-2016', 0),
(2, 'tcl', 1, 1000, 'falkjl;ajf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', NULL, NULL, '2016', '30-05-2016', 0),
(3, 'tcl', 1, 1000, 'falkjl;ajf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016', '30-05-2016', 0),
(4, 'tcl', 1, 1000, 'falkjl;ajf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '30-05-2016', 0),
(5, '', 0, 0, '', 'C/', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 0),
(6, '', 0, 0, '', 'C/', 'Ja', 'PH', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 0),
(7, '', 0, 0, '', NULL, 'Ja', 'PH', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 0),
(8, 'tcl', 1, 800, 'dfasdf', '1', '2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016', '20-06-2016', 0),
(9, 'tcl', 1, 1000, 'fsdfdf', NULL, NULL, '3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015', '20-06-2016', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_info`
--

CREATE TABLE IF NOT EXISTS `emp_info` (
  `emp_id` int(255) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `emp_f_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nid` int(255) NOT NULL,
  `mobile` int(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `degination` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `join_date` date NOT NULL,
  `resign_date` date NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `emp_info`
--

INSERT INTO `emp_info` (`emp_id`, `emp_name`, `emp_f_name`, `address`, `nid`, `mobile`, `email`, `degination`, `join_date`, `resign_date`) VALUES
(4, 'Md. Rakibul Islam(Rakib)', 'dfadsf', 'dsfsd', 111111111, 2344444, 'dfadsf', 'dsfadsf', '2018-09-29', '2018-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `holding_bank_data`
--

CREATE TABLE IF NOT EXISTS `holding_bank_data` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `bank_acc_no` varchar(255) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `holding_bank_data`
--

INSERT INTO `holding_bank_data` (`bank_id`, `bank_name`, `bank_address`, `bank_acc_no`) VALUES
(1, 'Sonali Bank', 'Akur Takurpara, Tangail', '100001'),
(2, 'Sonali Bank', 'Akur Takurpara, Tangail', '100001'),
(3, 'Sonali Bank', 'Akur Takurpara, Tangail', '100001');

-- --------------------------------------------------------

--
-- Table structure for table `homepage_admin`
--

CREATE TABLE IF NOT EXISTS `homepage_admin` (
  `a_name` varchar(255) NOT NULL,
  `a_password` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `homepage_admin`
--

INSERT INTO `homepage_admin` (`a_name`, `a_password`, `admin_id`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', 1),
('tread', '638a78b2f905522f230314fbe76d7ed9', 2),
('hold', 'af1d8213f4a22b0f9803fec9259ff7a8', 3),
('summation', '8799e6584bf5c4dc898cb936b219038e', 4),
('security', '1234', 5);

-- --------------------------------------------------------

--
-- Table structure for table `import`
--

CREATE TABLE IF NOT EXISTS `import` (
  `import_id` int(255) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `forma_size` varchar(255) NOT NULL,
  `press_name` varchar(255) NOT NULL,
  `num_book` int(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`import_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `import`
--

INSERT INTO `import` (`import_id`, `book_name`, `book_id`, `forma_size`, `press_name`, `num_book`, `date`) VALUES
(1, 'DUET physics', '', '1000x100', 'sanmick', 2800, '0000-00-00'),
(2, 'DUET Physics', '', '১৯৯৯০', 'rakib', 3444, '0000-00-00'),
(3, 'DUET Physics', '', '১৯৯৯০', 'rakib', 3444, '0000-00-00'),
(4, 'DUET Physics', '', '১৯৯৯০', 'rakib', 3444, '0000-00-00'),
(5, 'DUET Physics', '', '১৯৯৯০', 'rakib', 3444, '0000-00-00'),
(6, 'DUET Physics', '', '১৯৯৯০', 'rakib', 3444, '2018-09-13'),
(37, 'DUET Physics', 'S-107', '1000', 'rakib', 3500, '2018-09-19'),
(38, 'DUET Physics', 'S-107', '1000', 'rakib', 300, '2018-09-19'),
(39, 'DUET Physics', 'S-107', '1000', 'Sumick', 1000, '2018-09-23'),
(40, 'CSE', 'S-106', '200x1000', 'rakib', 20000, '2018-09-25'),
(41, 'CSE', 'S-106', '8998789', 'rakib', 1000, '2018-09-28'),
(42, 'DUET Math', 'S-111', 'gdfgdfgdfgd', 'rakib', 1000, '2018-10-25');

-- --------------------------------------------------------

--
-- Table structure for table `kordatha_info`
--

CREATE TABLE IF NOT EXISTS `kordatha_info` (
  `k_id` int(255) NOT NULL AUTO_INCREMENT,
  `word_no` int(255) NOT NULL,
  `holding_no` int(255) NOT NULL,
  `kordatha_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `f_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `vill_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `holding_address` varchar(255) CHARACTER SET latin1 NOT NULL,
  `holding_use` varchar(255) CHARACTER SET latin1 NOT NULL,
  `kordathar_doron` varchar(255) CHARACTER SET latin1 NOT NULL,
  `holding_doron` varchar(255) CHARACTER SET latin1 NOT NULL,
  `bank_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `yearly_tax` int(255) NOT NULL,
  `bokia_taka` varchar(255) NOT NULL,
  `bokia_year` varchar(255) NOT NULL,
  `bokia_kisti` varchar(255) NOT NULL,
  `d_entry_name` varchar(255) NOT NULL,
  `d_entry_post` varchar(255) NOT NULL,
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kordatha_info`
--

INSERT INTO `kordatha_info` (`k_id`, `word_no`, `holding_no`, `kordatha_id`, `name`, `f_name`, `vill_name`, `holding_address`, `holding_use`, `kordathar_doron`, `holding_doron`, `bank_name`, `yearly_tax`, `bokia_taka`, `bokia_year`, `bokia_kisti`, `d_entry_name`, `d_entry_post`) VALUES
(2, 0, 1, 101, 'rakib', 'rahim', 'purahata', 'purahata', 'à¦¬à§à¦¯à¦¬à¦¸à§à¦¯à¦¾à§Ÿà¦¿à¦•', 'à¦ªà§à¦°à¦¾à¦‡à¦­à§‡à¦Ÿ', 'à¦ªà¦¾à¦•à¦¾', 'p1', 1000, '0', '', '', 'rakib', 'compter operator'),
(3, 0, 2, 101, 'rakib', 'aaa', 'tangail', 'purahata', 'à¦¶à¦¿à¦²à§à¦ª à¦•à¦¾à¦°à¦–à¦¾à¦¨à¦¾', 'primary', 'à¦ªà¦¾à¦•à¦¾', 'p1', 1000, '0', '2013 - 2014', '2', 'rakib', 'compter operator'),
(4, 1, 1, 100, 'rakibul islam', 'rahim', 'adfasd', 'asddfasd', 'à¦¶à¦¿à¦²à§à¦ª à¦•à¦¾à¦°à¦–à¦¾à¦¨à¦¾', 'à¦ªà§à¦°à¦¾à¦‡à¦­à§‡à¦Ÿ', 'à¦•à¦¾à¦šà¦¾', 'p1', 2, '2', '2014 - 2015', '2', 'rakib', 'computer operator'),
(5, 3, 1, 100, 'rakibul islam', 'adv', 'adfasd', 'asddfasd', 'à¦†à¦¬à¦¾à¦¸à¦¿à¦•', 'à¦¸à¦°à¦•à¦¾à¦°à§€', 'à¦ªà¦¾à¦•à¦¾', 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', 20, '0', '2013 - 2014', '1', 'rakib', 'computer operator');

-- --------------------------------------------------------

--
-- Table structure for table `memo_report`
--

CREATE TABLE IF NOT EXISTS `memo_report` (
  `memo_id` int(255) NOT NULL AUTO_INCREMENT,
  `memo_num` int(255) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_id` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `total_price` int(255) NOT NULL,
  `paid` int(255) NOT NULL,
  `due` int(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`memo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `memo_report`
--

INSERT INTO `memo_report` (`memo_id`, `memo_num`, `shop_name`, `shop_id`, `book_id`, `quantity`, `rate`, `price`, `total_price`, `paid`, `due`, `date`) VALUES
(6, 54, 'duet boi-Bitan', '1222', 'S-107,S-107,S-104,S-104,S-104,S-104', '5,5,2,2,2,5', '100,100,200,200,200,200', '500,500,400,400,400,1000', 3200, 3200, 0, '2018-09-21'),
(7, 56, 'duet boi-Bitan', '1222', 'S-107,S-104', '8,6', '900,600', '7200,3600', 10800, 10000, 800, '2018-09-21'),
(8, 2, '', '', 'S-107,S-107', '8,7', '8,170', '64,1190', 1254, 0, 1254, '2018-09-22'),
(9, 3, '', '', 'S-107', '5', '6', '30', 30, 0, 30, '2018-09-22'),
(10, 4, 'duet boi-Bitan', '1222', 'S-104', '6', '6', '36', 36, 600, -564, '2018-09-22'),
(11, 5, '', '', 'S-107', '7', '7', '49', 49, 0, 49, '2018-09-22'),
(12, 6, '', '', 'S-104', '6', '6', '36', 36, 0, 36, '2018-09-22'),
(13, 7, 'duet boi-Bitan', '1222', 'S-107', '8', '8', '648', 648, 600, 48, '2018-09-22'),
(14, 8, 'duet boi-Bitan', '1222', 'S-104', '8', '8', '64', 64, 60, 4, '2018-09-22'),
(15, 9, 'duet boi-Bitan', '1222', 'S-107', '8', '8', '64', 64, 50, 14, '2018-09-22'),
(16, 9, 'duet boi-Bitan', '1222', 'S-107', '8', '8', '64', 64, 50, 14, '2018-09-22'),
(17, 11, 'duet boi-Bitan', '1222', 'S-104,S-107', '8,10', '100,200', '800,2000', 2800, 2000, 800, '2018-09-22'),
(18, 1, 'duet boi-Bitan', '1222', 'S-107', '5', '100', '500', 500, 500, 0, '2018-09-22'),
(20, 4, 'duet boi-Bitan', '1222', 'S-104,S-104', '5,500', '5,5', '25,2500', 2525, 2500, 25, '2018-09-22'),
(24, 104, 'duet boi-Bitan', '1222', 'S-104', '10', '200', '2000', 2000, 1000, 1000, '2018-09-28'),
(25, 105, 'duet boi-Bitan', '1222', 'S-107', '995', '250', '248750', 248750, 240000, 8750, '2018-09-25'),
(26, 106, 'duet boi-Bitan', '1222', 'S-104,S-107', '500,900', '100,250', '50000,225000', 0, 2000, 0, '2018-09-25'),
(27, 107, 'duet boi-Bitan', '1222', 'S-104', '10', '200', '2000', 2000, 1000, 1000, '2018-09-25'),
(28, 108, 'duet boi-Bitan', '1222', 'S-106', '500', '250', '125000', 125000, 10000, 115000, '2018-09-25'),
(30, 110, 'duet boi-Bitan', '1222', 'S-104', '5', '100', '500', 500, 500, 0, '2018-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `month_vara`
--

CREATE TABLE IF NOT EXISTS `month_vara` (
  `vara_id` int(11) NOT NULL AUTO_INCREMENT,
  `market_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `dokan_no` int(11) NOT NULL,
  `vara` int(11) NOT NULL,
  `vara_kothai` varchar(255) CHARACTER SET latin1 NOT NULL,
  `month_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `year_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `joma_date` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`vara_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `month_vara`
--

INSERT INTO `month_vara` (`vara_id`, `market_name`, `dokan_no`, `vara`, `vara_kothai`, `month_name`, `year_name`, `joma_date`) VALUES
(13, 'tcl', 1, 1000, 'some text', '6', '2016', '27-05-2016'),
(16, 'tcl', 1, 1000, 'falkjl;ajf', '12', '2016', '30-05-2016'),
(17, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 1000, 'some text', '6', '2016', '10-06-2016'),
(18, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 1000, 'uyuiyiuy', '1,2,3,10', '2016', '20-06-2016'),
(19, 'tcl', 1, 800, 'falkjl;ajf', '3,10,11', '2016', '20-06-2016'),
(20, 'tcl', 1, 1000, 'hjkhjkhk', '6', '2016', '21-06-2016'),
(21, 'tcl', 1, 1000, 'nkjklkl', '6,7,8', '2016', '21-06-2016'),
(22, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 500, 'jgljkjg', '1', '2017', '12-10-2017'),
(23, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 700, 'à¦¸à¦¾à¦¤ à¦¹à¦¾à¦œà¦¾à¦° à¦Ÿà¦¾à¦•à¦¾ à¦®à¦¾à¦¤à§à¦°', '1,2,3,4,5,6,7,8,9,10,11', '2017', '12-10-2017'),
(24, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 500, 'kjkjj', '1,2', '2017', '04-11-2017'),
(25, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 5000, 'hfhgfhg', '1', '2017', '08-11-2017'),
(26, 'tcl', 1, 500, 'dsgdsgdfs', '1,2,3,4,5', '2017', '05-12-2017'),
(27, 'à¦•à§à¦¯à¦¾à¦ªà¦¸à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ ', 2, 500, 'dasfdsfdas', '1,3,4,5', '2018', '04-02-2018'),
(28, 'tcl', 1, 500, 'gkfff', '4', '2018', '03-05-2018'),
(29, 'tcl', 1, 100000, 'gdfgf', '1,2,3', '2018', '20-07-2018');

-- --------------------------------------------------------

--
-- Table structure for table `operator_data`
--

CREATE TABLE IF NOT EXISTS `operator_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `operator_post` varchar(255) CHARACTER SET latin1 NOT NULL,
  `operator_password` varchar(11) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `press_info`
--

CREATE TABLE IF NOT EXISTS `press_info` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `press_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `m_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bank_no` varchar(255) CHARACTER SET utf8 NOT NULL,
  `mobile` int(255) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `press_info`
--

INSERT INTO `press_info` (`id`, `press_name`, `m_name`, `bank_no`, `mobile`, `email`, `address`) VALUES
(6, 'rakib', '0', '344', 1777342572, 'dd', 'dddd'),
(7, 'Sumick', '0', '122334444', 1777777, 'rakibdeveloper@gmail.com', 'dddd'),
(8, 'Sumick', 'abc', '344', 1777342572, 'rakibdeveloper@gmail.com', 'dddd'),
(9, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(10, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(11, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(12, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(13, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(14, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(15, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(16, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(17, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(18, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(19, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(20, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(21, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(22, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(23, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(24, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(25, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(26, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(30, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(31, 'rakib', 'dd', '344', 1777342572, 'dd', 'dddd'),
(32, 'Sumick', 'dd', '344', 1777342572, 'dd', 'dddd');

-- --------------------------------------------------------

--
-- Table structure for table `sells`
--

CREATE TABLE IF NOT EXISTS `sells` (
  `sell_id` int(255) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `price` int(255) NOT NULL,
  `total_price` int(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(255) NOT NULL,
  PRIMARY KEY (`sell_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sells`
--

INSERT INTO `sells` (`sell_id`, `book_name`, `book_id`, `quantity`, `price`, `total_price`, `date`, `status`) VALUES
(1, 'DUET Physics', 'S-107', 100, 250, 25000, '2018-10-25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sells_account`
--

CREATE TABLE IF NOT EXISTS `sells_account` (
  `sells_account_id` int(255) NOT NULL AUTO_INCREMENT,
  `shop_id` int(255) NOT NULL,
  `paid` int(255) NOT NULL,
  `due` int(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`sells_account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sells_account`
--

INSERT INTO `sells_account` (`sells_account_id`, `shop_id`, `paid`, `due`, `date`) VALUES
(1, 1222, 50, 14, '2018-09-22'),
(2, 1222, 2000, 800, '2018-09-22'),
(3, 1222, 500, 0, '2018-09-22'),
(4, 1222, 2100, 300, '2018-09-22'),
(5, 1222, 2500, 25, '2018-09-22'),
(6, 1222, 700, 5700, '2018-09-23'),
(7, 1222, 800, 100, '2018-09-23'),
(8, 1222, 2400, 0, '2018-09-23'),
(9, 1222, 1000, 1000, '2018-09-23'),
(10, 1222, 240000, 8750, '2018-09-25'),
(11, 1222, 270000, 5000, '2018-09-25'),
(12, 1222, 1000, 1000, '2018-09-25'),
(13, 1222, 10000, 115000, '2018-09-25'),
(14, 1222, 12000, 116500, '2018-09-25'),
(15, 1222, 500, 0, '2018-09-25'),
(16, 100, 2000, 1251, '2018-09-28');

-- --------------------------------------------------------

--
-- Table structure for table `stock_info`
--

CREATE TABLE IF NOT EXISTS `stock_info` (
  `stock_info_id` int(255) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `count_damage` int(255) NOT NULL,
  `count_stock` int(255) NOT NULL,
  PRIMARY KEY (`stock_info_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `stock_info`
--

INSERT INTO `stock_info` (`stock_info_id`, `book_name`, `book_id`, `count_damage`, `count_stock`) VALUES
(2, 'DUET English', 'S-104', 300, 5),
(4, 'CSE', 's-106', 0, 500),
(5, 'DUET Math', 'S-105', 100, 900),
(6, 'DUET Physics', '6677', 233, 0),
(9, 'DUET Physics', 'S-107', 1105, 905),
(10, 'DUET Math', 'S-111', 0, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tdl_bank_data`
--

CREATE TABLE IF NOT EXISTS `tdl_bank_data` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) NOT NULL,
  `bank_acc_no` varchar(255) NOT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tdl_bank_data`
--

INSERT INTO `tdl_bank_data` (`bank_id`, `bank_name`, `bank_acc_no`) VALUES
(1, 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', 'à§§à§¦à§¦'),
(2, 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', 'à§§à§¦à§¦'),
(3, 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', '4'),
(4, 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', '1'),
(5, 'hghf', '445555'),
(6, 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', 'à§§à§¦à§¦'),
(7, 'Sonali Bank', 'ww'),
(8, 'rakib', '56');

-- --------------------------------------------------------

--
-- Table structure for table `tdl_cost`
--

CREATE TABLE IF NOT EXISTS `tdl_cost` (
  `cost_id` int(11) NOT NULL AUTO_INCREMENT,
  `tdl_cost_b` text CHARACTER SET latin1 NOT NULL,
  `tdl_cost_taka` int(11) NOT NULL,
  `day` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `cost_date` varchar(255) NOT NULL,
  PRIMARY KEY (`cost_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tdl_cost`
--

INSERT INTO `tdl_cost` (`cost_id`, `tdl_cost_b`, `tdl_cost_taka`, `day`, `month`, `year`, `cost_date`) VALUES
(4, 'breakfast', 200, 30, 4, 2016, '05-06-2016'),
(13, 'tyrtrty', 200, 12, 5, 2016, '10-05-2016'),
(14, 'abakldf', 0, 25, 11, 2016, ''),
(15, 'abakldf', 0, 26, 11, 2016, ''),
(16, 'bread, Tea', 50, 6, 12, 2017, '');

-- --------------------------------------------------------

--
-- Table structure for table `tdl_joma`
--

CREATE TABLE IF NOT EXISTS `tdl_joma` (
  `tdl_id` int(255) NOT NULL AUTO_INCREMENT,
  `tdl_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `tdl_budget_year` varchar(255) CHARACTER SET latin1 NOT NULL,
  `tdl_fe` int(255) NOT NULL,
  `vat` varchar(255) CHARACTER SET latin1 NOT NULL,
  `tdl_incometex` int(255) NOT NULL,
  `tdl_jomriman` int(255) NOT NULL,
  `tdl_ohers_cost` int(255) NOT NULL,
  `total_taka` varchar(255) CHARACTER SET latin1 NOT NULL,
  `taka_kothai` varchar(255) CHARACTER SET latin1 NOT NULL,
  `tdl_bank_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `tdl_bank_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `joma_day` int(2) NOT NULL,
  `joma_month` int(2) NOT NULL,
  `joma_year` int(4) NOT NULL,
  `joma_date` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`tdl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tdl_joma`
--

INSERT INTO `tdl_joma` (`tdl_id`, `tdl_no`, `tdl_budget_year`, `tdl_fe`, `vat`, `tdl_incometex`, `tdl_jomriman`, `tdl_ohers_cost`, `total_taka`, `taka_kothai`, `tdl_bank_name`, `tdl_bank_no`, `joma_day`, `joma_month`, `joma_year`, `joma_date`) VALUES
(20, '100', 'à§¨à§¦à§§à§«-à§¨à§¦à§§à§¬', 1000, '150', 100, 0, 0, '1250', 'à¦à¦• à¦¹à¦¾à¦œà¦¾à¦° à¦¦à§à¦‡ à¦¶à¦¤ à¦ªà¦žà§à¦šà¦¾à¦¶ à¦Ÿà¦¾à¦•à¦¾ à¦®à¦¾à¦¤à§à¦°', 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', '8888', 18, 5, 2016, '18-05-2016'),
(21, '101', 'à§¨à§¦à§§à§«-à§¨à§¦à§§à§¬', 500, '75', 300, 0, 0, '875', 'klfjaslfjalf', 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', '599', 7, 6, 2016, '07-06-2016'),
(22, '100', 'à§¨à§¦à§§à§«-à§¨à§¦à§§à§¬', 500, '75', 100, 10, 48, '733', 'fjkljkfla', 'Sonali Bank', '5', 26, 11, 2016, '26-11-2016'),
(23, '111', 'à§¨à§¦à§§à§«-à§¨à§¦à§§à§¬', 1000, '150', 123, 22, 444, '1739', 'tt', 'à¦ªà§à¦°à¦¿à¦®à¦¿à§Ÿà¦¾à¦° à¦¬à§à¦¯à¦¾à¦‚à¦•', '1123', 3, 5, 2018, '03-05-2018');

-- --------------------------------------------------------

--
-- Table structure for table `tred_lisence_application`
--

CREATE TABLE IF NOT EXISTS `tred_lisence_application` (
  `app_id` int(255) NOT NULL AUTO_INCREMENT,
  `app_serial` int(255) NOT NULL,
  `app_name` text CHARACTER SET latin1 NOT NULL,
  `app_f_name` text CHARACTER SET latin1 NOT NULL,
  `app_m_name` text CHARACTER SET latin1 NOT NULL,
  `b_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `b_address_vill` text CHARACTER SET latin1 NOT NULL,
  `b_address_holding_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `b_address_word_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `b_address_post` text CHARACTER SET latin1 NOT NULL,
  `b_doron` text CHARACTER SET latin1 NOT NULL,
  `app_p_vill` text CHARACTER SET latin1 NOT NULL,
  `app_p_holding_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_p_word_no` int(255) NOT NULL,
  `app_p_post` text CHARACTER SET latin1 NOT NULL,
  `app_p_upzila` text CHARACTER SET latin1 NOT NULL,
  `app_p_zila` text CHARACTER SET latin1 NOT NULL,
  `app_s_vill` text CHARACTER SET latin1 NOT NULL,
  `app_s_holding_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_s_word_no` int(255) NOT NULL,
  `app_s_post` text CHARACTER SET latin1 NOT NULL,
  `app_s_upzila` text CHARACTER SET latin1 NOT NULL,
  `app_s_zila` text CHARACTER SET latin1 NOT NULL,
  `app_tin_num` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_mobile` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_email` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_treadlisence_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `treadlisence_year` int(255) NOT NULL,
  `data_entry_name` text CHARACTER SET latin1 NOT NULL,
  `app_photo` varchar(255) CHARACTER SET latin1 NOT NULL,
  `entry_post` varchar(255) CHARACTER SET latin1 NOT NULL,
  `app_date` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tred_lisence_application`
--

INSERT INTO `tred_lisence_application` (`app_id`, `app_serial`, `app_name`, `app_f_name`, `app_m_name`, `b_name`, `b_address_vill`, `b_address_holding_no`, `b_address_word_no`, `b_address_post`, `b_doron`, `app_p_vill`, `app_p_holding_no`, `app_p_word_no`, `app_p_post`, `app_p_upzila`, `app_p_zila`, `app_s_vill`, `app_s_holding_no`, `app_s_word_no`, `app_s_post`, `app_s_upzila`, `app_s_zila`, `app_tin_num`, `app_mobile`, `app_email`, `app_treadlisence_no`, `treadlisence_year`, `data_entry_name`, `app_photo`, `entry_post`, `app_date`) VALUES
(4, 8, 'Md. Nihat Hasan', 'Md. Lal mia', 'Mst. Runa Akter', 'RKB-IT', 'tangail', 'tangail', 'tangail', 'tangail', 'IT', 'tangail', '100', 0, 'tangail', 'tangail', 'tangail', 'tangail', '1000', 8, 'tangail', 'tangail', 'tangail', '', '1234567', '', '111', 2016, 'rakib', '8.jpg', 'rakib', '17-05-2016'),
(5, 6, 'Md. Rakibul Islam', 'Md. Lal mia', 'Mst. Runa Akter', 'RKB-IT', 'tangail', 'tangail', 'tangail', 'tangail', 'IT', 'tangail', '100', 0, 'tangail', 'tangail', 'tangail', 'tangail', '1000', 8, 'tangail', 'tangail', 'tangail', '', '1234567', '', '111', 2016, 'rakib', '7.jpg', 'rakib', '07-06-2016'),
(7, 8, 'Md. rakibul islam', 'aaaaaaaa', 'ggggg', 'it', 'tangail', 'tangail', 'tangail', 'tangail', 'computer', 'tangail', '9', 9, 'tangail', 'tangail', 'tangail', 'tangail', '09', 8, 'tangail', 'tangail', 'tangail', '', '12326266', '', '1000', 2016, 'rakib', '8.jpg', 'operator', '01-10-2017');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
